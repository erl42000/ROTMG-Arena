class Projectile:

    def __init__(self, damage, speed, duration, hitBox):
        self.damage = damage;
        self.speed = speed;
        self.duration = duration;
        self.hitBox = hitBox;
